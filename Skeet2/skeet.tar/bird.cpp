#include "bird.h"

int Bird::hit()
{
   return 0;
}

void Bird::draw()
{
}